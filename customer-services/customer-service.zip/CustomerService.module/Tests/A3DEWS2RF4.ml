<?xml version="1.0" encoding="ASCII"?>
<emulation:BWTFile xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:emulation="http:///emulation.ecore">
  <CurrentLoadedTest href="platform:/resource/CustomerService.module/Tests/CustomerDetailsTest.bwt#/"/>
  <EmulationDataFile>ACED0005740017437573746F6D657244657461696C73546573742E627774</EmulationDataFile>
</emulation:BWTFile>
